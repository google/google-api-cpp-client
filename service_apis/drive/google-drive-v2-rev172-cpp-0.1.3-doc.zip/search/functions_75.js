var searchData=
[
  ['user',['User',['../classgoogle__drive__api_1_1User.html#adf4996c1e63253aaf011bc00514bf395',1,'google_drive_api::User::User(const Json::Value &amp;storage)'],['../classgoogle__drive__api_1_1User.html#adda2ba724f544901fa63a645bfcaac69',1,'google_drive_api::User::User(Json::Value *storage)']]],
  ['userpicture',['UserPicture',['../classgoogle__drive__api_1_1User_1_1UserPicture.html#a61f1d590d6d4284f7c8fb2d3cb397918',1,'google_drive_api::User::UserPicture::UserPicture(const Json::Value &amp;storage)'],['../classgoogle__drive__api_1_1User_1_1UserPicture.html#a5fd676352b8e47ddeab92320e8842dc1',1,'google_drive_api::User::UserPicture::UserPicture(Json::Value *storage)']]]
];
