var searchData=
[
  ['timeperiod',['TimePeriod',['../classgoogle__calendar__api_1_1TimePeriod.html#a53fffaff232d607a16cfd51a7cf290d3',1,'google_calendar_api::TimePeriod::TimePeriod(const Json::Value &amp;storage)'],['../classgoogle__calendar__api_1_1TimePeriod.html#a60d44c18e20607751d6f08a04f9f5eb0',1,'google_calendar_api::TimePeriod::TimePeriod(Json::Value *storage)']]]
];
